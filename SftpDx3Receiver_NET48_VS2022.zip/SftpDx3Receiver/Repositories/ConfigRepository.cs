using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;
using SftpDx3Receiver.Models;
namespace SftpDx3Receiver.Repositories
{
    public sealed class ConfigRepository
    {
        private readonly string connectionString;
        public ConfigRepository(string value) { connectionString = value; }
        public ReceiveConfig Load()
        {
            var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand("SELECT CODE, STR1 FROM dbo.APSTR WHERE CODE LIKE @Prefix", connection))
            {
                command.Parameters.Add("@Prefix", SqlDbType.VarChar, 20).Value = "sftp%";
                connection.Open();
                using (var reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        string key = Convert.ToString(reader[0]).Trim();
                        if (values.ContainsKey(key)) throw new InvalidOperationException("Duplicate APSTR CODE: " + key);
                        values.Add(key, Convert.ToString(reader[1]).Trim());
                    }
            }
            var result = new ReceiveConfig {
                Host = Required(values, "sftpHost"), ResourceCode = Required(values, "sftpResCode"),
                AppCode = values.ContainsKey("sftpAppCode") ? values["sftpAppCode"] : "",
                Port = 22, Companies = new List<CompanyReceiveConfig>()
            };
            int parsedPort;
            if (values.ContainsKey("sftpPort") &&
                (!int.TryParse(values["sftpPort"], out parsedPort) ))
                throw new InvalidOperationException("Invalid sftpPort.");
            if (values.ContainsKey("sftpPort")) result.Port = int.Parse(values["sftpPort"]);
            if (result.Port < 1 || result.Port > 65535) throw new InvalidOperationException("Invalid sftpPort.");
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in Required(values, "sftpCompCode").Split('^'))
            {
                string corp = part.Trim();
                if (!Regex.IsMatch(corp, "^[0-9]{2}$") || !seen.Add(corp))
                    throw new InvalidOperationException("sftpCompCode requires unique two-digit codes separated by ^.");
                string remote = Required(values, "sftpFilePath" + corp);
                string local = Required(values, "sftpLocalPath" + corp);
                if (!remote.StartsWith("/") || remote.Contains("\\"))
                    throw new InvalidOperationException("Remote path must be absolute POSIX path: " + corp);
                if (!(Regex.IsMatch(local, @"^[A-Za-z]:[\\/]") || local.StartsWith(@"\\")))
                    throw new InvalidOperationException("Local path must be absolute drive or UNC path: " + corp);
                result.Companies.Add(new CompanyReceiveConfig { CorpNo = corp, RemotePath = remote, LocalPath = Path.GetFullPath(local) });
            }
            return result;
        }
        private static string Required(Dictionary<string, string> values, string key)
        {
            string value;
            if (!values.TryGetValue(key, out value) || string.IsNullOrWhiteSpace(value) || value.Contains("YOUR_"))
                throw new InvalidOperationException("Missing/unconfigured APSTR: " + key);
            return value;
        }
    }
}
