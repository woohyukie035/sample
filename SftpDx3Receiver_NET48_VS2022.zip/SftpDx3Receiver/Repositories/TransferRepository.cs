using System;
using System.Data;
using System.Data.SqlClient;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Services;
namespace SftpDx3Receiver.Repositories
{
    public sealed class TransferRepository
    {
        private readonly BatchSettings settings;
        public TransferRepository(BatchSettings value) { settings = value; }
        public bool Exists(string corp, string name)
        {
            using (var c = new SqlConnection(settings.ConnectionString))
            using (var cmd = new SqlCommand("SELECT TOP (1) 1 FROM dbo.tblLifeInsurance WHERE CorpNo=@CorpNo AND FileName=@FileName", c))
            {
                AddKey(cmd, corp, name); c.Open(); return cmd.ExecuteScalar() != null;
            }
        }
        public bool InsertIfMissing(TransferRecord row)
        {
            using (var c = new SqlConnection(settings.ConnectionString))
            {
                c.Open();
                using (var tx = c.BeginTransaction(IsolationLevel.Serializable))
                using (var cmd = new SqlCommand(@"
IF NOT EXISTS (SELECT 1 FROM dbo.tblLifeInsurance WITH (UPDLOCK,HOLDLOCK)
               WHERE CorpNo=@CorpNo AND FileName=@FileName)
BEGIN
 INSERT dbo.tblLifeInsurance (CorpNo,FileName,FileData,FileState,AddressIp,NowMonth,Bid_Date,Bid_Man)
 VALUES (@CorpNo,@FileName,@FileData,@FileState,@AddressIp,@NowMonth,GETDATE(),@BidMan);
 SELECT CAST(1 AS int);
END
ELSE SELECT CAST(0 AS int);", c, tx))
                {
                    AddKey(cmd, row.CorpNo, row.FileName);
                    cmd.Parameters.Add("@FileData", SqlDbType.Image).Value = row.FileData;
                    // TODO: R/Z meaning MUST be confirmed; no inferred transition or default.
                    cmd.Parameters.Add("@FileState", SqlDbType.Char, 1).Value = settings.FileState;
                    cmd.Parameters.Add("@AddressIp", SqlDbType.Char, 20).Value = Nullable(settings.AddressIp);
                    cmd.Parameters.Add("@NowMonth", SqlDbType.Char, 10).Value = Nullable(settings.NowMonth);
                    cmd.Parameters.Add("@BidMan", SqlDbType.NVarChar, 50).Value = settings.BidMan;
                    cmd.CommandTimeout = settings.Timeout;
                    bool inserted = Convert.ToInt32(cmd.ExecuteScalar()) == 1;
                    tx.Commit(); return inserted;
                }
            }
        }
        private static object Nullable(string value) { return string.IsNullOrWhiteSpace(value) ? (object)DBNull.Value : value; }
        private static void AddKey(SqlCommand cmd, string corp, string name)
        {
            if (corp.Length > 10 || name.Length == 0 || name.Length > 120)
                throw new InvalidOperationException("CorpNo/FileName exceeds existing schema.");
            cmd.Parameters.Add("@CorpNo", SqlDbType.NChar, 10).Value = corp;
            cmd.Parameters.Add("@FileName", SqlDbType.NVarChar, 120).Value = name;
        }
    }
}
