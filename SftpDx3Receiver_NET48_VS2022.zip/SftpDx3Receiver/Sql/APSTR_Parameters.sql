/*
TEST-only template. Existing APSTR may have additional NOT NULL columns or composite keys.
Review Schema_Check.sql and adapt inserts first. Never replace a shared company list blindly.
This script makes no changes by default; set @Apply=1 only after editing TEST values.
*/
SET XACT_ABORT ON;
DECLARE @Apply bit = 0;
DECLARE @Parameters TABLE (CODE varchar(50), STR1 nvarchar(1000));
INSERT @Parameters VALUES
('sftpHost', 'YOUR_TEST_SFTP_HOST'),
('sftpPort', '22'),
('sftpAppCode', 'GOANYWHERE_T1'),
('sftpResCode', 'FTP_0002'),
('sftpCompCode', '05^22'),
('sftpFilePath05', '/YOUR_CONFIRMED_TEST_REMOTE_05/'),
('sftpFilePath22', '/YOUR_CONFIRMED_TEST_REMOTE_22/'),
('sftpLocalPath05', 'D:\BatchData\SftpReceive\Allianz'),
('sftpLocalPath22', 'D:\BatchData\SftpReceive\Paris');
SELECT * FROM @Parameters;
IF @Apply = 0 RETURN;
IF EXISTS (SELECT 1 FROM @Parameters WHERE STR1 LIKE '%YOUR_%')
    THROW 50000, 'Replace TEST placeholders first.', 1;
BEGIN TRANSACTION;
IF EXISTS (SELECT a.CODE FROM dbo.APSTR a JOIN @Parameters p ON p.CODE=a.CODE
           GROUP BY a.CODE HAVING COUNT(*)>1)
BEGIN
    ROLLBACK;
    THROW 50001, 'Duplicate APSTR keys; confirm schema scope.', 1;
END;
UPDATE a SET STR1=p.STR1 FROM dbo.APSTR a JOIN @Parameters p ON a.CODE=p.CODE;
INSERT dbo.APSTR (CODE,STR1)
SELECT p.CODE,p.STR1 FROM @Parameters p
WHERE NOT EXISTS (SELECT 1 FROM dbo.APSTR a WITH (UPDLOCK,HOLDLOCK) WHERE a.CODE=p.CODE);
COMMIT;

