-- Read-only: run in the intended TEST database. No CREATE/ALTER of existing tables.
SELECT DB_NAME() AS CurrentDatabase;
SELECT OBJECT_SCHEMA_NAME(c.object_id) AS SchemaName, OBJECT_NAME(c.object_id) AS TableName,
 c.name, t.name AS DataType, c.max_length, c.is_nullable, c.is_identity,
 dc.definition AS DefaultExpression
FROM sys.columns c
JOIN sys.types t ON c.user_type_id=t.user_type_id
LEFT JOIN sys.default_constraints dc ON c.default_object_id=dc.object_id
WHERE c.object_id IN (OBJECT_ID('dbo.APSTR'),OBJECT_ID('dbo.tblLifeInsurance'))
ORDER BY c.object_id,c.column_id;
SELECT CorpNo,FileName,COUNT_BIG(*) AS DuplicateCount
FROM dbo.tblLifeInsurance GROUP BY CorpNo,FileName HAVING COUNT_BIG(*)>1;
-- DBA review only, not executed:
-- CREATE UNIQUE INDEX UX_tblLifeInsurance_CorpNo_FileName
-- ON dbo.tblLifeInsurance(CorpNo,FileName);
-- Existing duplicates/business rules must be resolved before considering this index.

