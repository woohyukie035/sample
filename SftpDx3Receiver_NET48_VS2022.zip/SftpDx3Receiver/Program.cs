using System;
using System.Configuration;
using SftpDx3Receiver.Repositories;
using SftpDx3Receiver.Services;
namespace SftpDx3Receiver
{
    internal static class Program
    {
        // No ReadKey/ReadLine: Control-M must receive an exit code without interaction.
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length > 1 || (args.Length == 1 && args[0] != "--validate"))
                    throw new ConfigurationErrorsException("Usage: SftpDx3Receiver.exe [--validate]");
                var settings = BatchSettings.Load();
                var config = new ConfigRepository(settings.ConnectionString).Load();
                var credential = new SftpCredentialProvider().Resolve(config.AppCode, config.ResourceCode);
                if (args.Length == 1)
                {
                    LogService.Info("Configuration validated; DB APSTR read. No SFTP connection, download or INSERT performed.");
                    return 0;
                }
                LogService.Info("Batch started.");
                return new SftpReceiveService(settings).Run(config, credential);
            }
            catch (ConfigurationErrorsException ex) { LogService.Error(ex.Message); return 2; }
            catch (NotImplementedException ex) { LogService.Error(ex.Message); return 2; }
            catch (Exception ex)
            {
                // Avoid logging SQL connection strings, passwords or server-returned sensitive text.
                LogService.Error("Batch failed: " + ex.GetType().Name + ". Inspect exception in TEST debugger.");
                return 1;
            }
        }
    }
}
