using System.Collections.Generic;
namespace SftpDx3Receiver.Models
{
    public sealed class CompanyReceiveConfig
    {
        public string CorpNo { get; set; }
        public string RemotePath { get; set; }
        public string LocalPath { get; set; }
    }
    public sealed class ReceiveConfig
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string AppCode { get; set; }
        public string ResourceCode { get; set; }
        public List<CompanyReceiveConfig> Companies { get; set; }
    }
    public sealed class SftpCredential
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
    public sealed class TransferRecord
    {
        public string CorpNo { get; set; }
        public string FileName { get; set; }
        public byte[] FileData { get; set; }
    }
}
