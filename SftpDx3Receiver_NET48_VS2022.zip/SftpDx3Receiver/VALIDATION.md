# 驗證紀錄

驗證日期：2026-09-15。

## 已通過

- 所有 C# 原始碼以 Windows .NET Framework C# 編譯器實際編譯成功，無編譯錯誤。
- 編譯參照官方 SSH.NET 2026.0.0 NuGet 中的 lib/net462/Renci.SshNet.dll，未使用模擬 SFTP API。
- 參照 System.Data.dll、System.Configuration.dll；使用 Framework 同步 API。
- .csproj 與 App.config XML 可解析，所有 Compile 項目均存在。
- 啟動預設 App.config：明確顯示 SchemaReviewed TODO，回傳 exit code 2，未讀 DB／連 SFTP。

## 驗證界線

本機無 Visual Studio 2022 或 .NET SDK，因此未進行完整 VS/MSBuild NuGet 還原與建置，
也未驗證 NuGet 全部相依 DLL 的執行期載入與 binding redirects。
上述直接編譯是語法和實際 SSH.NET API 相容性檢查，不等同完整 VS2022 建置驗收。
請依 README 在 VS2022 還原並 Build；執行端須部署完整輸出目錄。

未提供可用的 TEST DB、SFTP Credential、host key，因此未執行 DB INSERT 或實際收檔。
資料表 DDL、constraints、trigger、並行防重和 IO／網路故障情境須依 README 在 TEST 驗收。
ZIP 提供原始專案，不包含此局部驗證產生的 exe 或單獨下載的套件 DLL。
