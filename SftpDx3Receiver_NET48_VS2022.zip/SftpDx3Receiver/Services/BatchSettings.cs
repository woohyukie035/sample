using System;
using System.Configuration;
namespace SftpDx3Receiver.Services
{
    public sealed class BatchSettings
    {
        public string ConnectionString;
        public string FileState;
        public string AddressIp;
        public string NowMonth;
        public string BidMan;
        public string Fingerprint;
        public long MaxFileBytes;
        public int MinimumAge;
        public int Timeout;
        public static string Get(string key) { return ConfigurationManager.AppSettings[key] ?? ""; }
        public static BatchSettings Load()
        {
            if (!string.Equals(Get("SchemaReviewed"), "true", StringComparison.OrdinalIgnoreCase))
                throw new ConfigurationErrorsException("TODO: review SQL schema and set SchemaReviewed=true.");
            var s = new BatchSettings();
            var connection = ConfigurationManager.ConnectionStrings["OutTransferFiles"];
            if (connection == null || connection.ConnectionString.Contains("YOUR_TEST"))
                throw new ConfigurationErrorsException("Configure TEST database connection.");
            s.ConnectionString = connection.ConnectionString;
            s.FileState = Get("FileState");
            if (s.FileState.Trim().Length != 1)
                throw new ConfigurationErrorsException("TODO: FileState R/Z rule is unconfirmed. Explicit value required.");
            s.AddressIp = Get("AddressIp"); s.NowMonth = Get("NowMonth"); s.BidMan = Get("BidMan");
            if (s.AddressIp.Length > 20 || s.NowMonth.Length > 10 || s.BidMan.Length == 0 || s.BidMan.Length > 50)
                throw new ConfigurationErrorsException("Invalid metadata lengths.");
            s.Fingerprint = Get("HostKeySha256");
            if (!s.Fingerprint.StartsWith("SHA256:", StringComparison.Ordinal) ||
                Convert.FromBase64String(s.Fingerprint.Substring(7).TrimEnd('=') + "=").Length != 32)
                throw new ConfigurationErrorsException("Configure trusted SHA256 host key.");
            s.Fingerprint = s.Fingerprint.TrimEnd('=');
            if (!long.TryParse(Get("MaxFileBytes"), out s.MaxFileBytes) || s.MaxFileBytes < 1 || s.MaxFileBytes > int.MaxValue)
                throw new ConfigurationErrorsException("MaxFileBytes must be 1..2147483647.");
            if (!int.TryParse(Get("MinimumFileAgeSeconds"), out s.MinimumAge) || s.MinimumAge < 0)
                throw new ConfigurationErrorsException("Invalid MinimumFileAgeSeconds.");
            if (!int.TryParse(Get("TimeoutSeconds"), out s.Timeout) || s.Timeout < 1 || s.Timeout > 3600)
                throw new ConfigurationErrorsException("TimeoutSeconds must be 1..3600.");
            return s;
        }
    }
}
