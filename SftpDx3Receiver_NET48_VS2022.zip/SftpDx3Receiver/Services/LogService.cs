using System;
namespace SftpDx3Receiver.Services
{
    public static class LogService
    {
        public static void Info(string message) { Console.WriteLine(DateTimeOffset.Now.ToString("o") + " INFO " + Clean(message)); }
        public static void Error(string message) { Console.Error.WriteLine(DateTimeOffset.Now.ToString("o") + " ERROR " + Clean(message)); }
        private static string Clean(string text) { return text.Replace("\r", " ").Replace("\n", " "); }
    }
}
