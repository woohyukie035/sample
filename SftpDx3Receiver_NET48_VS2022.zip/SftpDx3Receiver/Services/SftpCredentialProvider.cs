using System;
using SftpDx3Receiver.Models;
namespace SftpDx3Receiver.Services
{
    public sealed class SftpCredentialProvider
    {
        public SftpCredential Resolve(string appCode, string resourceCode)
        {
            if (BatchSettings.Get("CredentialMode") != "TestEnvironment")
                throw new NotImplementedException("TODO: implement enterprise credential lookup using sftpAppCode / sftpResCode (FTP_0002).");
            // TEST-only explicit opt-in. Never store real passwords in source/App.config/APSTR.
            string user = Environment.GetEnvironmentVariable(BatchSettings.Get("TestUserEnvironmentVariable"));
            string password = Environment.GetEnvironmentVariable(BatchSettings.Get("TestPasswordEnvironmentVariable"));
            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrEmpty(password))
                throw new InvalidOperationException("TEST credential environment variables are missing.");
            return new SftpCredential { UserName = user, Password = password };
        }
    }
}
