using System;
using System.IO;
using System.Security.Cryptography;
using Renci.SshNet;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Repositories;
namespace SftpDx3Receiver.Services
{
    public sealed class SftpReceiveService
    {
        private readonly BatchSettings settings;
        public SftpReceiveService(BatchSettings value) { settings = value; }
        public int Run(ReceiveConfig config, SftpCredential credential)
        {
            int failures = 0, inserted = 0, skipped = 0, deferred = 0;
            var repository = new TransferRepository(settings);
            var files = new FileService();
            using (var client = new SftpClient(config.Host, config.Port, credential.UserName, credential.Password))
            {
                client.ConnectionInfo.Timeout = TimeSpan.FromSeconds(settings.Timeout);
                client.OperationTimeout = TimeSpan.FromSeconds(settings.Timeout);
                client.HostKeyReceived += (sender, args) => {
                    using (var sha = SHA256.Create())
                        args.CanTrust = ("SHA256:" + Convert.ToBase64String(sha.ComputeHash(args.HostKey)).TrimEnd('=')) == settings.Fingerprint;
                };
                client.Connect();
                foreach (var company in config.Companies)
                {
                    try
                    {
                        foreach (var item in client.ListDirectory(company.RemotePath))
                        {
                            if (!item.IsRegularFile || item.IsSymbolicLink) continue;
                            if (item.Name.EndsWith(".part", StringComparison.OrdinalIgnoreCase) ||
                                (DateTime.UtcNow - item.LastWriteTimeUtc).TotalSeconds < settings.MinimumAge)
                            { deferred++; continue; }
                            try
                            {
                                FileService.ValidateName(item.Name);
                                if (repository.Exists(company.CorpNo, item.Name))
                                { skipped++; LogService.Info("SKIP " + company.CorpNo + "/" + item.Name); continue; }
                                string directory = Path.Combine(company.LocalPath, company.CorpNo,
                                    DateTime.UtcNow.ToString("yyyyMMdd"), Guid.NewGuid().ToString("N"));
                                string local = files.Download(client, company.RemotePath.TrimEnd('/') + "/" + item.Name,
                                    directory, item.Name, settings.MaxFileBytes);
                                // Preserve downloaded file if DB fails. Retry downloads to a new attempt directory.
                                bool added = repository.InsertIfMissing(new TransferRecord {
                                    CorpNo = company.CorpNo, FileName = item.Name, FileData = files.ReadBinary(local)
                                });
                                if (added) inserted++; else skipped++;
                                LogService.Info((added ? "INSERT " : "SKIP race ") + company.CorpNo + "/" + item.Name + " local=" + local);
                            }
                            catch (Exception ex)
                            {
                                failures++;
                                LogService.Error(company.CorpNo + "/" + item.Name + " failed: " + ex.GetType().Name);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        failures++; LogService.Error("Company " + company.CorpNo + " failed: " + ex.GetType().Name);
                    }
                }
                client.Disconnect();
            }
            LogService.Info("Summary inserted=" + inserted + " skipped=" + skipped + " deferred=" + deferred + " failed=" + failures);
            return failures == 0 ? 0 : 1;
        }
    }
}
