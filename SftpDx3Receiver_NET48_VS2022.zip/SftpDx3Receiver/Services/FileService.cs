using System;
using System.IO;
using System.Text.RegularExpressions;
using Renci.SshNet;
namespace SftpDx3Receiver.Services
{
    public sealed class FileService
    {
        public static void ValidateName(string name)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Length > 120 ||
                name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name == "." || name == ".." ||
                name.EndsWith(".") || name.EndsWith(" ") ||
                Regex.IsMatch(name, @"^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])($|\.)", RegexOptions.IgnoreCase))
                throw new IOException("Unsupported Windows/DB file name.");
        }
        public string Download(SftpClient client, string remote, string directory, string name, long maxBytes)
        {
            ValidateName(name);
            var before = client.GetAttributes(remote);
            if (!before.IsRegularFile || before.IsSymbolicLink || before.Size > maxBytes)
                throw new IOException("Remote type or size is not supported.");
            // Unique attempt directory prevents overwrites and cross-process .part collisions.
            Directory.CreateDirectory(directory);
            string final = Path.Combine(directory, name);
            string part = final + ".part";
            try
            {
                using (var output = new FileStream(part, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    client.DownloadFile(remote, output, count => {
                        if (count > (ulong)maxBytes) throw new IOException("File exceeded MaxFileBytes during download.");
                    });
                    output.Flush(true);
                }
                var after = client.GetAttributes(remote);
                if (!after.IsRegularFile || after.IsSymbolicLink || before.Size != after.Size ||
                    before.LastWriteTimeUtc != after.LastWriteTimeUtc || new FileInfo(part).Length != before.Size)
                    throw new IOException("Remote changed or downloaded size mismatched.");
                File.Move(part, final);
                return final;
            }
            catch
            {
                try { if (File.Exists(part)) File.Delete(part); } catch { /* Orphan .part: operator may clean after job stops. */ }
                throw;
            }
        }
        public byte[] ReadBinary(string path) { return File.ReadAllBytes(path); }
    }
}
