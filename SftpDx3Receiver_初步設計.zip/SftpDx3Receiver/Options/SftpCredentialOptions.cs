namespace SftpDx3Receiver.Options;
public sealed class SftpCredentialOptions
{
    public string UserName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
