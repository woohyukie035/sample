namespace SftpDx3Receiver.Options;
public sealed class ReceiverOptions
{
    public string ConfigTable { get; set; } = "dbo.APSTR";
    public string TargetTable { get; set; } = "dbo.tblLifeInsurance";
    public int DefaultSftpPort { get; set; } = 22;
    public bool SkipDuplicateByFileName { get; set; } = true;
    public bool DeleteRemoteAfterSuccess { get; set; } = false;
    public bool CreateDateFolder { get; set; } = false;
    public string DateFolderFormat { get; set; } = "yyyyMMdd";
    public string DefaultFileState { get; set; } = "R";
    public string BidMan { get; set; } = "SftpDx3Receiver";
}
