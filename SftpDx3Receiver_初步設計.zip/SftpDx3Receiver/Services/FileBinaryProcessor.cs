namespace SftpDx3Receiver.Services;
public sealed class FileBinaryProcessor
{
    public Task<byte[]> ReadAsync(string path,CancellationToken ct=default)=>File.ReadAllBytesAsync(path,ct);
}
