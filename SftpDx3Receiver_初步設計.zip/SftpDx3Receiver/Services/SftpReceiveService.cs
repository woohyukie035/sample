using System.Net;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Renci.SshNet;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Options;
using SftpDx3Receiver.Repositories;

namespace SftpDx3Receiver.Services;
public sealed class SftpReceiveService
{
    private readonly ConfigRepository _config; private readonly TransferRepository _repo; private readonly SftpCredentialProvider _cred; private readonly FileBinaryProcessor _binary; private readonly ReceiverOptions _options; private readonly ILogger<SftpReceiveService> _logger;
    public SftpReceiveService(ConfigRepository config,TransferRepository repo,SftpCredentialProvider cred,FileBinaryProcessor binary,IOptions<ReceiverOptions> options,ILogger<SftpReceiveService> logger){_config=config;_repo=repo;_cred=cred;_binary=binary;_options=options.Value;_logger=logger;}

    public async Task<TransferResult> ExecuteAsync(CancellationToken ct=default)
    {
        var result=new TransferResult(); var cfg=await _config.LoadAsync(ct); var (user,pwd)=_cred.GetCredential(cfg.ResourceCode);
        using var client=new SftpClient(cfg.Host,cfg.Port,user,pwd); client.Connect();
        foreach(var company in cfg.Companies) await ProcessCompanyAsync(client,company,result,ct);
        client.Disconnect(); return result;
    }

    private async Task ProcessCompanyAsync(SftpClient client,CompanyReceiveConfig c,TransferResult result,CancellationToken ct)
    {
        var files=client.ListDirectory(c.RemotePath).Where(x=>!x.IsDirectory&&!x.IsSymbolicLink).Where(x=>Match(x.Name,c.FilePattern)).ToArray();
        foreach(var f in files)
        {
            result.Total++;
            try
            {
                if(_options.SkipDuplicateByFileName && await _repo.ExistsAsync(c.CorpNo,f.Name,ct)){result.Skipped++; continue;}
                var localDir=_options.CreateDateFolder?Path.Combine(c.LocalPath,DateTime.Now.ToString(_options.DateFolderFormat)):c.LocalPath;
                Directory.CreateDirectory(localDir);
                var finalPath=Path.Combine(localDir,f.Name); var partPath=finalPath+".part"; if(File.Exists(partPath)) File.Delete(partPath);
                await using(var fs=new FileStream(partPath,FileMode.CreateNew,FileAccess.Write,FileShare.None)){client.DownloadFile($"{c.RemotePath.TrimEnd('/')}/{f.Name}",fs);} 
                if(new FileInfo(partPath).Length!=f.Length) throw new IOException("Downloaded file size mismatch.");
                File.Move(partPath,finalPath,true);
                var bytes=await _binary.ReadAsync(finalPath,ct);
                await _repo.InsertAsync(new TransferRecord{CorpNo=c.CorpNo,FileName=f.Name,FileData=bytes,FileState=_options.DefaultFileState,AddressIp=GetLocalIpv4(),NowMonth=DateTime.Now.ToString("yyyyMM"),BidDate=DateTime.Now,BidMan=_options.BidMan},ct);
                if(_options.DeleteRemoteAfterSuccess) client.DeleteFile($"{c.RemotePath.TrimEnd('/')}/{f.Name}");
                result.Success++; _logger.LogInformation("Success {CorpNo}/{File}",c.CorpNo,f.Name);
            }
            catch(Exception ex){result.Failed++; _logger.LogError(ex,"Failed {CorpNo}/{File}",c.CorpNo,f.Name);}
        }
    }
    private static bool Match(string fileName,string pattern)=>string.IsNullOrWhiteSpace(pattern)||pattern=="*"||System.IO.Enumeration.FileSystemName.MatchesSimpleExpression(pattern,fileName,true);
    private static string GetLocalIpv4(){try{return Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault(x=>x.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork)?.ToString()??"";}catch{return "";}}
}
