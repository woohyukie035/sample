using Microsoft.Extensions.Options;
using SftpDx3Receiver.Options;
namespace SftpDx3Receiver.Services;
public sealed class SftpCredentialProvider
{
    private readonly SftpCredentialOptions _options;
    public SftpCredentialProvider(IOptions<SftpCredentialOptions> options)=>_options=options.Value;
    public (string UserName,string Password) GetCredential(string? resourceCode)
    {
        if(string.IsNullOrWhiteSpace(_options.UserName)) throw new InvalidOperationException($"SFTP credential missing. ResourceCode={resourceCode}");
        return (_options.UserName,_options.Password);
    }
}
