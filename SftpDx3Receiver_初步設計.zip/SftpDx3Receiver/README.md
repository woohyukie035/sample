# SftpDx3Receiver 初步設計

## 本階段範圍
- 安聯：CorpNo 05
- 法巴：CorpNo 22
- 遠雄 25、凱基 17 暫不納入

## 流程
Control-M → Console → 讀 APSTR → SFTP GET → 搬到 DX3 → ReadAllBytes → INSERT dbo.tblLifeInsurance

## APSTR 參數
- sftpHost
- sftpPort（選配，預設 22）
- sftpResCode
- sftpCompCode
- sftpFilePath05 / sftpLocalPath05 / sftpFilePattern05（Pattern 選配）
- sftpFilePath22 / sftpLocalPath22 / sftpFilePattern22（Pattern 選配）

## 目前「解析」定義
目前先不解析 CSV/TXT/ZIP 欄位內容，只把完整檔案讀成 byte[] 並寫入 tblLifeInsurance.FileData（既有 image 欄位）。

## 初步處理規則
- 下載先寫 .part，檔案大小確認一致後再 rename。
- 預設 CorpNo + FileName 已存在就 SKIP。
- SFTP 原檔預設不刪除。
- Local Path 為本次新增 APSTR 參數。

## 正式開發前要確認
1. FileState R / Z 真正意義。
2. sftpResCode=FTP_0002 如何取得正式帳密或 Key。
3. 安聯、法巴實際 GoAnywhere Remote Path。
4. DX3 正式 Local Path。
5. 同名檔規則。
6. SFTP 成功後原檔保留 / 刪除 / 搬 History。
7. 公司實際 .NET Runtime / NuGet 套件規範。

## Build
Visual Studio 2022 開啟 SftpDx3Receiver.csproj，先 Restore NuGet，再 Build。
