using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SftpDx3Receiver.Options;
using SftpDx3Receiver.Repositories;
using SftpDx3Receiver.Services;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.Configure<ReceiverOptions>(builder.Configuration.GetSection("Receiver"));
builder.Services.Configure<SftpCredentialOptions>(builder.Configuration.GetSection("SftpCredential"));
builder.Services.AddSingleton<ConfigRepository>();
builder.Services.AddSingleton<TransferRepository>();
builder.Services.AddSingleton<SftpCredentialProvider>();
builder.Services.AddSingleton<FileBinaryProcessor>();
builder.Services.AddSingleton<SftpReceiveService>();

using var host = builder.Build();
var logger = host.Services.GetRequiredService<ILoggerFactory>().CreateLogger("Program");
try
{
    var result = await host.Services.GetRequiredService<SftpReceiveService>().ExecuteAsync();
    logger.LogInformation("Finished. Total={Total}, Success={Success}, Skipped={Skipped}, Failed={Failed}", result.Total, result.Success, result.Skipped, result.Failed);
    Environment.ExitCode = result.Failed > 0 ? 1 : 0;
}
catch (Exception ex)
{
    logger.LogCritical(ex, "Unhandled exception.");
    Environment.ExitCode = 99;
}
