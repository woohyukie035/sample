namespace SftpDx3Receiver.Models;
public sealed class ReceiverConfig
{
    public string Host { get; init; } = string.Empty;
    public int Port { get; init; } = 22;
    public string? ResourceCode { get; init; }
    public IReadOnlyList<CompanyReceiveConfig> Companies { get; init; } = Array.Empty<CompanyReceiveConfig>();
}
