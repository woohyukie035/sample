namespace SftpDx3Receiver.Models;
public sealed class TransferResult { public int Total { get; set; } public int Success { get; set; } public int Skipped { get; set; } public int Failed { get; set; } }
