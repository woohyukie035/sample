namespace SftpDx3Receiver.Models;
public sealed class CompanyReceiveConfig
{
    public string CorpNo { get; init; } = string.Empty;
    public string RemotePath { get; init; } = string.Empty;
    public string LocalPath { get; init; } = string.Empty;
    public string FilePattern { get; init; } = "*";
}
