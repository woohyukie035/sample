namespace SftpDx3Receiver.Models;
public sealed class TransferRecord
{
    public string CorpNo { get; init; } = string.Empty;
    public string FileName { get; init; } = string.Empty;
    public byte[] FileData { get; init; } = Array.Empty<byte>();
    public string FileState { get; init; } = "R";
    public string AddressIp { get; init; } = string.Empty;
    public string? NowMonth { get; init; }
    public DateTime BidDate { get; init; } = DateTime.Now;
    public string BidMan { get; init; } = string.Empty;
}
