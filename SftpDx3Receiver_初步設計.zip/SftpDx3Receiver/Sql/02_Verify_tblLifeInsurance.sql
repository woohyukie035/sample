SELECT TOP (20) iNo,RTRIM(CorpNo) CorpNo,FileName,FileState,AddressIp,NowMonth,Bid_Date,Bid_Man,Upd_date,Upd_man FROM dbo.tblLifeInsurance ORDER BY iNo DESC;
SELECT FileState,COUNT(*) Cnt FROM dbo.tblLifeInsurance GROUP BY FileState ORDER BY FileState;
