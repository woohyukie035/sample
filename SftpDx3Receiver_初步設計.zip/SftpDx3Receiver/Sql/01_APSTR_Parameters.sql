-- 本次新增 Local Path 參數初稿，正式路徑請先確認。
IF NOT EXISTS (SELECT 1 FROM dbo.APSTR WHERE CODE='sftpLocalPath05')
INSERT INTO dbo.APSTR (CODE,STR1,MEMO) VALUES ('sftpLocalPath05','D:\BatchData\Files\SftpDx3Receiver\Allianz\',N'安聯 SFTP 收回 DX3 路徑');
IF NOT EXISTS (SELECT 1 FROM dbo.APSTR WHERE CODE='sftpLocalPath22')
INSERT INTO dbo.APSTR (CODE,STR1,MEMO) VALUES ('sftpLocalPath22','D:\BatchData\Files\SftpDx3Receiver\Paris\',N'法巴 SFTP 收回 DX3 路徑');
