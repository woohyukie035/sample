using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Options;

namespace SftpDx3Receiver.Repositories;
public sealed class TransferRepository
{
    private readonly string _cs; private readonly ReceiverOptions _options;
    public TransferRepository(IConfiguration config, IOptions<ReceiverOptions> options)
    {
        _cs=config.GetConnectionString("OutTransferFiles") ?? throw new InvalidOperationException("Missing connection string OutTransferFiles.");
        _options=options.Value;
    }

    public async Task<bool> ExistsAsync(string corpNo,string fileName,CancellationToken ct=default)
    {
        await using var conn=new SqlConnection(_cs); await conn.OpenAsync(ct);
        var sql=$"SELECT TOP (1) 1 FROM {SafeObjectName(_options.TargetTable)} WHERE RTRIM(CorpNo)=@CorpNo AND FileName=@FileName";
        await using var cmd=new SqlCommand(sql,conn);
        cmd.Parameters.Add("@CorpNo",SqlDbType.NChar,10).Value=corpNo;
        cmd.Parameters.Add("@FileName",SqlDbType.NVarChar,120).Value=fileName;
        return await cmd.ExecuteScalarAsync(ct) is not null;
    }

    public async Task InsertAsync(TransferRecord r,CancellationToken ct=default)
    {
        await using var conn=new SqlConnection(_cs); await conn.OpenAsync(ct);
        var sql=$@"INSERT INTO {SafeObjectName(_options.TargetTable)}
(CorpNo,FileName,FileData,FileState,AddressIp,NowMonth,Bid_Date,Bid_Man,Upd_date,Upd_man)
VALUES(@CorpNo,@FileName,@FileData,@FileState,@AddressIp,@NowMonth,@BidDate,@BidMan,NULL,NULL)";
        await using var cmd=new SqlCommand(sql,conn);
        cmd.Parameters.Add("@CorpNo",SqlDbType.NChar,10).Value=r.CorpNo;
        cmd.Parameters.Add("@FileName",SqlDbType.NVarChar,120).Value=r.FileName;
        cmd.Parameters.Add("@FileData",SqlDbType.Image).Value=r.FileData;
        cmd.Parameters.Add("@FileState",SqlDbType.Char,1).Value=r.FileState;
        cmd.Parameters.Add("@AddressIp",SqlDbType.Char,20).Value=string.IsNullOrWhiteSpace(r.AddressIp)?DBNull.Value:r.AddressIp;
        cmd.Parameters.Add("@NowMonth",SqlDbType.Char,10).Value=string.IsNullOrWhiteSpace(r.NowMonth)?DBNull.Value:r.NowMonth;
        cmd.Parameters.Add("@BidDate",SqlDbType.DateTime).Value=r.BidDate;
        cmd.Parameters.Add("@BidMan",SqlDbType.NVarChar,50).Value=r.BidMan;
        await cmd.ExecuteNonQueryAsync(ct);
    }
    private static string SafeObjectName(string value)
    {
        var parts=value.Split('.',StringSplitOptions.RemoveEmptyEntries);
        if(parts.Length is <1 or >2 || parts.Any(p=>p.Any(ch=>!(char.IsLetterOrDigit(ch)||ch=='_')))) throw new InvalidOperationException($"Invalid SQL object name: {value}");
        return string.Join('.', parts.Select(p=>$"[{p}]"));
    }
}
