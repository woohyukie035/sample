using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Options;

namespace SftpDx3Receiver.Repositories;
public sealed class ConfigRepository
{
    private readonly string _cs;
    private readonly ReceiverOptions _options;
    private readonly ILogger<ConfigRepository> _logger;
    public ConfigRepository(IConfiguration config, IOptions<ReceiverOptions> options, ILogger<ConfigRepository> logger)
    {
        _cs = config.GetConnectionString("OutTransferFiles") ?? throw new InvalidOperationException("Missing connection string OutTransferFiles.");
        _options = options.Value; _logger = logger;
    }

    public async Task<ReceiverConfig> LoadAsync(CancellationToken ct = default)
    {
        var map = new Dictionary<string,string?>(StringComparer.OrdinalIgnoreCase);
        await using var conn = new SqlConnection(_cs);
        await conn.OpenAsync(ct);
        var sql = $"SELECT CODE, STR1 FROM {SafeObjectName(_options.ConfigTable)} WHERE CODE LIKE 'sftp%'";
        await using var cmd = new SqlCommand(sql, conn);
        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct)) map[rd["CODE"].ToString()!.Trim()] = rd["STR1"] as string;

        string Req(string key) => map.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v.Trim() : throw new InvalidOperationException($"Missing APSTR parameter: {key}");
        var companies = new List<CompanyReceiveConfig>();
        foreach (var corpNo in Req("sftpCompCode").Split('^', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var rKey=$"sftpFilePath{corpNo}"; var lKey=$"sftpLocalPath{corpNo}"; var pKey=$"sftpFilePattern{corpNo}";
            if (!map.TryGetValue(rKey, out var remote) || string.IsNullOrWhiteSpace(remote)) { _logger.LogWarning("Skip {CorpNo}: missing {Key}", corpNo, rKey); continue; }
            if (!map.TryGetValue(lKey, out var local) || string.IsNullOrWhiteSpace(local)) { _logger.LogWarning("Skip {CorpNo}: missing {Key}", corpNo, lKey); continue; }
            companies.Add(new CompanyReceiveConfig { CorpNo=corpNo, RemotePath=remote.Trim(), LocalPath=local.Trim(), FilePattern=map.TryGetValue(pKey,out var pat)&&!string.IsNullOrWhiteSpace(pat)?pat.Trim():"*" });
        }
        if (companies.Count==0) throw new InvalidOperationException("No valid company configuration found.");
        return new ReceiverConfig { Host=Req("sftpHost"), Port=map.TryGetValue("sftpPort",out var pv)&&int.TryParse(pv,out var port)?port:_options.DefaultSftpPort, ResourceCode=map.TryGetValue("sftpResCode",out var rc)?rc?.Trim():null, Companies=companies };
    }

    private static string SafeObjectName(string value)
    {
        var parts=value.Split('.',StringSplitOptions.RemoveEmptyEntries);
        if(parts.Length is <1 or >2 || parts.Any(p=>p.Any(ch=>!(char.IsLetterOrDigit(ch)||ch=='_')))) throw new InvalidOperationException($"Invalid SQL object name: {value}");
        return string.Join('.', parts.Select(p=>$"[{p}]"));
    }
}
