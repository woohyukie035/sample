#!/usr/bin/env node
/**
 * mdtodocx.js — Convert Markdown to DOCX
 *
 * Usage:
 *   node mdtodocx.js <input.md> [output.docx]
 *
 * Features:
 *   - Headings H1–H6, paragraphs, blockquotes, horizontal rules
 *   - Bold, italic, strikethrough, inline code, hyperlinks
 *   - Fenced code blocks (monospace with background)
 *   - Mermaid diagrams → rendered as PNG images (requires mmdc in PATH)
 *   - GFM tables with aligned header
 *   - Ordered / unordered / task-list items (nested up to 4 levels)
 *   - Embedded images (relative paths resolved from MD file's directory)
 */

'use strict';

const path = require('path');
const fs   = require('fs');
const os   = require('os');
const { execSync, spawnSync } = require('child_process');

// ─── Argument parsing ────────────────────────────────────────────────────────
const [,, inputArg, outputArg] = process.argv;
if (!inputArg) {
  console.error('Usage: node mdtodocx.js <input.md> [output.docx]');
  process.exit(1);
}
const inputPath  = path.resolve(inputArg);
const outputPath = outputArg
  ? path.resolve(outputArg)
  : inputPath.replace(/\.md$/i, '') + '.docx';
const mdDir = path.dirname(inputPath);

if (!fs.existsSync(inputPath)) {
  console.error('File not found:', inputPath);
  process.exit(1);
}

// ─── Load dependencies ───────────────────────────────────────────────────────
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  ImageRun, HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, ExternalHyperlink, PageBreak,
} = require('docx');
const { marked, Lexer } = require('marked');

// ─── Constants ───────────────────────────────────────────────────────────────
const FONT        = 'Arial';
const FONT_MONO   = 'Courier New';
const SIZE_NORMAL = 22;   // 11pt
const SIZE_CODE   = 18;   // 9pt
const SIZE_SMALL  = 20;   // 10pt

// A4 page, 2 cm margins on each side
const PAGE_W = 11906;
const MARGIN  = 1134;   // ~2 cm in DXA
const CONTENT_W_DXA = PAGE_W - MARGIN * 2;           // 9638 DXA
const CONTENT_W_PX  = Math.round(CONTENT_W_DXA / 1440 * 96); // ≈ 643 px

const HEADING_STYLES = {
  1: { size: 40, color: '1F3864', headingLevel: HeadingLevel.HEADING_1 },
  2: { size: 32, color: '2E4057', headingLevel: HeadingLevel.HEADING_2 },
  3: { size: 28, color: '2E4057', headingLevel: HeadingLevel.HEADING_3 },
  4: { size: 24, color: '333333', headingLevel: HeadingLevel.HEADING_4 },
  5: { size: 22, color: '555555', headingLevel: HeadingLevel.HEADING_5 },
  6: { size: 20, color: '777777', headingLevel: HeadingLevel.HEADING_6 },
};

// ─── Numbering configuration ─────────────────────────────────────────────────
// References: "ul0"–"ul3" for unordered, "ol0"–"ol3" for ordered
const BULLET_CHARS = ['•', '◦', '▪', '-'];
const INDENT_BASE  = 360;  // DXA per level

function makeNumberingConfig() {
  const config = [];
  for (let lvl = 0; lvl < 4; lvl++) {
    config.push({
      reference: `ul${lvl}`,
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: BULLET_CHARS[lvl],
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: INDENT_BASE * (lvl + 1), hanging: 360 } } },
      }],
    });
    config.push({
      reference: `ol${lvl}`,
      levels: [{
        level: 0, format: LevelFormat.DECIMAL, text: '%1.',
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: INDENT_BASE * (lvl + 1), hanging: 360 } } },
      }],
    });
  }
  return config;
}

// ─── Image utilities ─────────────────────────────────────────────────────────
const EXT_TO_TYPE = { '.png': 'png', '.jpg': 'jpg', '.jpeg': 'jpeg',
                      '.gif': 'gif', '.bmp': 'bmp', '.svg': 'svg' };

function loadImageFile(href) {
  // Resolve relative paths from MD directory; skip absolute URLs
  if (/^https?:\/\//i.test(href)) return null;
  const imgPath = path.isAbsolute(href) ? href : path.join(mdDir, href);
  if (!fs.existsSync(imgPath)) return null;
  const ext  = path.extname(imgPath).toLowerCase();
  const type = EXT_TO_TYPE[ext];
  if (!type) return null;
  const data = fs.readFileSync(imgPath);
  return { data, type, path: imgPath };
}

function scaleImage(w, h, maxW) {
  if (w <= maxW) return { width: w, height: h };
  return { width: maxW, height: Math.round(h * maxW / w) };
}

function imageDimensions(imgPath) {
  // Use .NET System.Drawing on Windows to get dimensions; fallback 400×300
  try {
    const ps = spawnSync('powershell', [
      '-NoProfile', '-Command',
      `Add-Type -AssemblyName System.Drawing;`
      + `$b=[System.Drawing.Bitmap]::new('${imgPath.replace(/'/g, "''")}');`
      + `Write-Output "$($b.Width) $($b.Height)";$b.Dispose()`,
    ], { encoding: 'utf8' });
    if (ps.status === 0) {
      const [w, h] = ps.stdout.trim().split(' ').map(Number);
      if (w > 0 && h > 0) return { width: w, height: h };
    }
  } catch (_) {}
  return { width: 400, height: 300 };
}

function makeImageParagraph(href, alt) {
  const img = loadImageFile(href);
  if (!img) return null;
  const raw   = imageDimensions(img.path);
  const trans = scaleImage(raw.width, raw.height, CONTENT_W_PX);
  return new Paragraph({
    children: [new ImageRun({
      type: img.type, data: img.data,
      transformation: trans,
      altText: { title: alt || 'image', description: alt || '', name: 'img' },
    })],
    spacing: { before: 120, after: 120 },
  });
}

// ─── Mermaid renderer ────────────────────────────────────────────────────────
let mmdcAvailable = null;
function checkMmdc() {
  if (mmdcAvailable !== null) return mmdcAvailable;
  try { execSync('mmdc --version', { stdio: 'ignore' }); mmdcAvailable = true; }
  catch (_) { mmdcAvailable = false; }
  return mmdcAvailable;
}

function renderMermaid(mmdText) {
  if (!checkMmdc()) return null;
  const tmpDir  = fs.mkdtempSync(path.join(os.tmpdir(), 'mmd-'));
  const mmdFile = path.join(tmpDir, 'diagram.mmd');
  const pngFile = path.join(tmpDir, 'diagram.png');
  try {
    fs.writeFileSync(mmdFile, mmdText, 'utf8');
    execSync(`mmdc -i "${mmdFile}" -o "${pngFile}" -b white`, { stdio: 'pipe' });
    if (!fs.existsSync(pngFile)) return null;
    const data = fs.readFileSync(pngFile);
    const dims = imageDimensions(pngFile);
    const trans = scaleImage(dims.width, dims.height, CONTENT_W_PX);
    return new Paragraph({
      children: [new ImageRun({
        type: 'png', data,
        transformation: trans,
        altText: { title: 'Diagram', description: 'Mermaid diagram', name: 'mermaid' },
      })],
      spacing: { before: 120, after: 120 },
    });
  } catch (e) {
    console.warn('  ⚠ Mermaid render failed:', e.message);
    return null;
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (_) {}
  }
}

// ─── Inline content → docx children ─────────────────────────────────────────
function runStyle(style) {
  const r = { font: FONT, size: style.size || SIZE_NORMAL };
  if (style.bold)    r.bold    = true;
  if (style.italics) r.italics = true;
  if (style.strike)  r.strike  = true;
  if (style.color)   r.color   = style.color;
  return r;
}

function processInline(tokens, style = {}) {
  const children = [];
  for (const tok of (tokens || [])) {
    switch (tok.type) {
      case 'text':
        if (tok.tokens) {
          children.push(...processInline(tok.tokens, style));
        } else {
          children.push(new TextRun({ text: tok.text, ...runStyle(style) }));
        }
        break;
      case 'escape':
        children.push(new TextRun({ text: tok.text, ...runStyle(style) }));
        break;
      case 'strong':
        children.push(...processInline(tok.tokens, { ...style, bold: true }));
        break;
      case 'em':
        children.push(...processInline(tok.tokens, { ...style, italics: true }));
        break;
      case 'del':
        children.push(...processInline(tok.tokens, { ...style, strike: true }));
        break;
      case 'codespan':
        children.push(new TextRun({
          text: tok.text, font: FONT_MONO, size: SIZE_CODE,
          shading: { fill: 'F0F0F0', type: ShadingType.CLEAR },
        }));
        break;
      case 'link': {
        const linkChildren = processInline(
          tok.tokens || [{ type: 'text', text: tok.text }],
          { ...style, color: '1155CC' }
        ).filter(c => c instanceof TextRun);
        if (linkChildren.length && tok.href) {
          children.push(new ExternalHyperlink({ link: tok.href, children: linkChildren }));
        } else {
          children.push(...linkChildren);
        }
        break;
      }
      case 'image': {
        const imgPara = makeImageParagraph(tok.href, tok.text);
        // Inline images: embed data directly as ImageRun if possible
        if (imgPara) {
          const imgRun = imgPara.options?.children?.[0];
          if (imgRun) children.push(imgRun);
        }
        break;
      }
      case 'br':
        children.push(new TextRun({ break: 1 }));
        break;
      case 'html':
        // strip tags, keep text content
        children.push(new TextRun({ text: tok.text.replace(/<[^>]*>/g, ''), ...runStyle(style) }));
        break;
      case 'space':
        break;
    }
  }
  return children;
}

// ─── Block-level token processors ────────────────────────────────────────────
function makeHeading(tok) {
  const hs = HEADING_STYLES[tok.depth] || HEADING_STYLES[6];
  const textChildren = processInline(tok.tokens, { size: hs.size, color: hs.color, bold: true });
  const para = new Paragraph({
    heading: hs.headingLevel,
    children: textChildren.length ? textChildren
      : [new TextRun({ text: tok.text, font: FONT, size: hs.size, bold: true, color: hs.color })],
    spacing: { before: tok.depth === 1 ? 360 : 240, after: 120 },
  });
  return [para];
}

function makeCodeBlock(tok) {
  const lang = (tok.lang || '').toLowerCase().trim();

  // Mermaid → render as image
  if (lang === 'mermaid') {
    const imgPara = renderMermaid(tok.text);
    if (imgPara) return [imgPara];
    // fallback: code block
  }

  const lines = tok.text.split('\n');
  const paras = [];
  // Label line
  if (lang && lang !== 'mermaid') {
    paras.push(new Paragraph({
      children: [new TextRun({ text: lang, font: FONT, size: 16, color: '888888', bold: true })],
      spacing: { before: 120, after: 0 },
      shading: { fill: 'E8E8E8', type: ShadingType.CLEAR },
      indent: { left: 240, right: 240 },
    }));
  }
  // Code lines
  for (const line of lines) {
    paras.push(new Paragraph({
      children: [new TextRun({ text: line || ' ', font: FONT_MONO, size: SIZE_CODE, color: '1A1A1A' })],
      spacing: { before: 0, after: 0 },
      shading: { fill: 'F5F5F5', type: ShadingType.CLEAR },
      indent: { left: 240, right: 240 },
    }));
  }
  // Bottom padding
  paras.push(new Paragraph({
    children: [new TextRun({ text: '' })],
    spacing: { before: 0, after: 120 },
    shading: { fill: 'F5F5F5', type: ShadingType.CLEAR },
    indent: { left: 240, right: 240 },
  }));
  return paras;
}

function makeParagraph(tok) {
  // Check if it's a standalone image paragraph
  if (tok.tokens && tok.tokens.length === 1 && tok.tokens[0].type === 'image') {
    const imgTok = tok.tokens[0];
    const imgPara = makeImageParagraph(imgTok.href, imgTok.text);
    if (imgPara) return [imgPara];
  }
  const children = processInline(tok.tokens);
  if (!children.length) return [];
  return [new Paragraph({ children, spacing: { before: 80, after: 80 } })];
}

function makeBlockquote(tok) {
  const inner = processTokens(tok.tokens);
  // Wrap each inner paragraph with left border / indentation
  return inner.map(el => {
    if (el instanceof Paragraph) {
      // Re-create with indentation
      const opts = el.options || {};
      return new Paragraph({
        ...(opts),
        indent: { left: 480 },
        border: { left: { style: BorderStyle.SINGLE, size: 12, color: 'CCCCCC', space: 12 } },
        shading: { fill: 'F9F9F9', type: ShadingType.CLEAR },
      });
    }
    return el;
  });
}

function makeHR() {
  return new Paragraph({
    children: [new TextRun({ text: '' })],
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC', space: 4 } },
    spacing: { before: 120, after: 120 },
  });
}

// List processor with depth tracking
function makeList(tok, depth = 0) {
  const elements = [];
  const ref = tok.ordered ? `ol${Math.min(depth, 3)}` : `ul${Math.min(depth, 3)}`;

  for (const item of tok.items) {
    const isTask = item.task;
    const checked = item.checked;

    if (isTask) {
      // Task list item
      const mark = checked ? '☑' : '☐';
      const inlineTokens = item.tokens.filter(t => t.type === 'text' || t.type === 'paragraph');
      let textContent = item.text;
      let inlineChildren = [];

      // Get first paragraph's inline content
      const firstPara = item.tokens.find(t => t.type === 'paragraph');
      if (firstPara) {
        inlineChildren = processInline(firstPara.tokens);
      } else {
        const textTok = item.tokens.find(t => t.type === 'text');
        if (textTok && textTok.tokens) {
          inlineChildren = processInline(textTok.tokens);
        } else {
          inlineChildren = [new TextRun({ text: textContent, font: FONT, size: SIZE_NORMAL })];
        }
      }

      elements.push(new Paragraph({
        children: [
          new TextRun({ text: `${mark}  `, font: FONT, size: SIZE_NORMAL }),
          ...inlineChildren,
        ],
        spacing: { before: 60, after: 60 },
        indent: { left: INDENT_BASE * (depth + 1) },
      }));
    } else {
      // Normal list item - first text/paragraph node
      const firstBlock = item.tokens.find(t => t.type === 'text' || t.type === 'paragraph');
      let inlineChildren = [];

      if (firstBlock) {
        inlineChildren = processInline(firstBlock.tokens || [{ type: 'text', text: firstBlock.text }]);
      }

      elements.push(new Paragraph({
        numbering: { reference: ref, level: 0 },
        children: inlineChildren.length
          ? inlineChildren
          : [new TextRun({ text: item.text, font: FONT, size: SIZE_NORMAL })],
        spacing: { before: 60, after: 60 },
      }));
    }

    // Nested lists or additional blocks within item
    for (const subTok of item.tokens) {
      if (subTok.type === 'list') {
        elements.push(...makeList(subTok, depth + 1));
      } else if (subTok.type === 'code') {
        elements.push(...makeCodeBlock(subTok));
      } else if (subTok.type === 'blockquote') {
        elements.push(...makeBlockquote(subTok));
      }
    }
  }
  return elements;
}

function makeTable(tok) {
  const colCount = tok.header.length;
  const colW = Math.floor(CONTENT_W_DXA / colCount);
  const colWidths = Array(colCount).fill(colW);
  // Fix rounding: last column absorbs remainder
  colWidths[colCount - 1] += CONTENT_W_DXA - colW * colCount;

  const border = { style: BorderStyle.SINGLE, size: 4, color: 'AAAAAA' };
  const borders = { top: border, bottom: border, left: border, right: border };

  function align(a) {
    if (a === 'center') return AlignmentType.CENTER;
    if (a === 'right')  return AlignmentType.RIGHT;
    return AlignmentType.LEFT;
  }

  function makeCell(tokens, isHeader, alignment) {
    const children = processInline(tokens);
    return new TableCell({
      borders,
      width: { size: colWidths[0], type: WidthType.DXA }, // approximate
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      shading: isHeader ? { fill: '1F3864', type: ShadingType.CLEAR } : undefined,
      children: [new Paragraph({
        children: children.length
          ? children.map(c => {
              if (c instanceof TextRun) {
                const opts = c.options || {};
                return new TextRun({
                  ...opts,
                  bold: isHeader ? true : opts.bold,
                  color: isHeader ? 'FFFFFF' : opts.color,
                });
              }
              return c;
            })
          : [new TextRun({ text: '', font: FONT, size: SIZE_SMALL })],
        alignment: align(alignment),
      })],
    });
  }

  const rows = [];

  // Header row
  rows.push(new TableRow({
    tableHeader: true,
    children: tok.header.map((cell, i) =>
      makeCell(cell.tokens, true, tok.align?.[i])
    ),
  }));

  // Data rows
  for (const row of tok.rows) {
    rows.push(new TableRow({
      children: row.map((cell, i) =>
        makeCell(cell.tokens, false, tok.align?.[i])
      ),
    }));
  }

  return new Table({
    width: { size: CONTENT_W_DXA, type: WidthType.DXA },
    columnWidths: colWidths,
    rows,
  });
}

// ─── Main token dispatcher ───────────────────────────────────────────────────
function processTokens(tokens) {
  const elements = [];
  for (const tok of tokens) {
    switch (tok.type) {
      case 'heading':    elements.push(...makeHeading(tok));           break;
      case 'paragraph':  elements.push(...makeParagraph(tok));         break;
      case 'code':       elements.push(...makeCodeBlock(tok));         break;
      case 'table':      elements.push(makeTable(tok));                break;
      case 'list':       elements.push(...makeList(tok));              break;
      case 'blockquote': elements.push(...makeBlockquote(tok));        break;
      case 'hr':         elements.push(makeHR());                      break;
      case 'html':       /* skip raw HTML */                           break;
      case 'space':      /* skip whitespace tokens */                  break;
      default:           /* unknown — skip */                          break;
    }
  }
  return elements;
}

// ─── Build document ──────────────────────────────────────────────────────────
async function main() {
  const mdText = fs.readFileSync(inputPath, 'utf8');

  // Parse with GFM (tables, task lists, strikethrough)
  const lexer  = new Lexer({ gfm: true, breaks: false });
  const tokens = lexer.lex(mdText);

  console.log(`Converting: ${path.basename(inputPath)} → ${path.basename(outputPath)}`);

  const children = processTokens(tokens);

  const doc = new Document({
    numbering: { config: makeNumberingConfig() },
    styles: {
      default: { document: { run: { font: FONT, size: SIZE_NORMAL } } },
    },
    sections: [{
      properties: {
        page: {
          size: { width: PAGE_W, height: 16838 },
          margin: { top: MARGIN, right: MARGIN, bottom: MARGIN, left: MARGIN },
        },
      },
      children,
    }],
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputPath, buffer);
  console.log(`Done: ${outputPath} (${(buffer.length / 1024).toFixed(1)} KB)`);
}

main().catch(err => { console.error(err); process.exit(1); });
