# SftpDx3Receiver

Visual Studio 2022 / C# Console / .NET Framework 4.8。由 Control-M 直接啟動 exe。
本版是可開啟的初版專案，正式 Credential 與 FileState 規則仍待確認。

## 流程與架構

```text
Program → App.config → ConfigRepository / dbo.APSTR
 → SftpCredentialProvider → SftpReceiveService
 → SFTP GET → DX3 .part → 大小與修改時間檢查 → 正式檔
 → File.ReadAllBytes() → TransferRepository → dbo.tblLifeInsurance
```

- Program.cs：入口、--validate 與退出碼。
- Models：公司設定、連線設定、Credential、收檔資料。
- Services：設定驗證、Credential TODO、SFTP 收檔、檔案與 Console 日誌。
- Repositories：System.Data.SqlClient / ADO.NET，參數化 SQL。
- Sql：APSTR 測試參數範例、唯讀 Schema 檢查。
- App.config：DB、測試模式、明確指定的收檔狀態與執行限制。
- 無 Generic Host、DI Container、await using 或非 Framework 4.8 API。

## 共用 CodeBasedSftp 與 DLL 參照

本版使用你提供的 RealTimeNoticeLibrary.CodeBasedSftp 原始碼，保留原有公開方法，
新增 GetAttributes、DownloadFile，以及 TimeoutSeconds / HostKeySha256 設定。
補上私鑰資源釋放、連線失敗清理；指定私鑰但檔案不存在時明確失敗。
只有 Services/CodeBasedSftp.cs 直接操作 SftpClient；批次服務透過共用類別列檔及下載。
本 Console 不呼叫共用類別的上傳、遠端刪除或搬移方法。
原 namespace 保留為 RealTimeNoticeLibrary，不要再同時加入另一份相同類別原始碼。

已移除 NuGet PackageReference，改用編譯機共用 Renci.SshNet.dll 的 HintPath。
CodeBasedSftp 本身仍使用 SSH.NET；本版沿用公司共用 DLL，不固定或下載新版套件。

1. 安裝 VS2022「.NET 桌面開發」與 .NET Framework 4.8 Developer/Targeting Pack。
2. 將 SharedReferences.props.example 複製為 SharedReferences.props，
   把 SharedReferencePath 改為實際共用 DLL 目錄，例如 D:\ref。
   這是範例路徑，尚未得知編譯機實際位置。
3. 未提供設定時預設找專案上一層 ref；若目錄就是磁碟根目錄，可直接指定 D:\。
4. 共用目錄須有 Renci.SshNet.dll 及該版本所需的 .NET Framework 相容相依 DLL。
   不需將整個 ref 目錄的所有 DLL 加到專案。
5. 開啟 SftpDx3Receiver.sln，Build Debug / Any CPU，不需要 NuGet Restore。
   MSBuild 會解析參照並複製相依組件；部署前確認輸出包含共用版本所需的完整 DLL。
   缺少 Renci.SshNet.dll 時會顯示 SharedReferencePath 設定錯誤。
6. 編譯機也可使用：

```text
MSBuild.exe SftpDx3Receiver.sln /t:Build /p:Configuration=Release /p:SharedReferencePath=D:\ref
```

參照路徑是編譯時用途，DX3 執行時仍需 exe 同目錄的相依 DLL。
不需要 DX3 存取編譯機的 ref 目錄。完整建置與執行相容性須以公司實際 DLL 版本驗證。

## APSTR：既有 dbo.APSTR 的 CODE → STR1

| CODE | TEST 設定 |
|---|---|
| sftpHost | 實際 TEST GoAnywhere/SFTP host，不含 sftp:// |
| sftpPort | 可選；缺省 22 |
| sftpAppCode | 可選；傳給 Credential Provider 的應用代碼 |
| sftpResCode | FTP_0002（資源代碼，並非密碼） |
| sftpCompCode | 05^22 |
| sftpFilePath05 / 22 | 各公司的絕對 SFTP 路徑，如 /confirmed/path/ |
| sftpLocalPath05 / 22 | 本次新增，各公司的 DX3 絕對實體路徑或 UNC 路徑 |

公司清單使用 ^ 分隔，保留前置零、拒絕空白項與重複代碼。程式沒有 hardcode 05/22。
未來新增公司只需更新清單與对应 Remote/Local 參數。
目前假設共同 SFTP host／Credential，不直接連各保險公司的外部 host。
不要把保險公司視角的路徑直接當作 GoAnywhere 的可見路徑。

既有 sftpCompCode 若被其他批次共用，不可直接在正式環境改成 05^22；
先於隔離 TEST DB 驗證，再協調參數範圍。CODE 必須在此查詢範圍內唯一。
目前假設 CODE、STR1；若既有 APSTR 有額外分群條件或必填欄位，
須調整 ConfigRepository 查詢與 SQL 範例。

## 本機 F5 Debug

1. 解壓縮並開啟 .sln；設為啟始專案，確認目標 .NET Framework 4.8，設定共用參照並 Build。
2. 準備隔離 TEST DB，使用既有表結構的測試副本。執行 Sql/Schema_Check.sql。
   確認 iNo 是 identity 或有 default；未 INSERT 的 Upd_date / Upd_man 等欄位允許 NULL 或有 default。
   確認 APSTR 欄位、長度、CODE 唯一性與 INSERT 權限。
3. App.config 設定 TEST SQL connection string。預設 Windows 驗證：
   執行 VS 的帳號須有 APSTR SELECT，以及 tblLifeInsurance SELECT/INSERT 權限。
   SQL Server TLS 憑證須受信任；依公司 TEST 環境調整連線設定。
4. 編輯 Sql/APSTR_Parameters.sql 的 TEST host、remote path、DX3 local path；
   預設只顯示參數。確認後才將 @Apply 改為 1，在 TEST DB 執行。
5. App.config 設 SchemaReviewed=true。FileState 必須由業務／既有程式確認後填入。
   若僅用測試專用狀態，也須確認 TEST 表的限制允許。程式不自動假設 R 或 Z。
   AddressIp、NowMonth 空值會寫 SQL NULL，若欄位不允許 NULL，請先確認定義後明確填入。
6. 向 SFTP 管理者取得可信的 SHA256 host key fingerprint，填入 HostKeySha256，
   格式為 SHA256:後接 Base64（可有或無結尾 =）。不接受未知 host key。
7. 僅 TEST 可設定 CredentialMode=TestEnvironment。以環境變數提供
   SFTP_DX3_TEST_USER 與 SFTP_DX3_TEST_PASSWORD；不要將密碼寫進程式、App.config、
   SQL 或版本控制。若設定使用者環境變數，須重啟 VS 才會繼承；完成後清除。
   正式 Resource 模式尚未實作，會明確失敗，不會偷偷切換測試模式。
8. Project Properties → Debug → Command line arguments 填 --validate，
   在 Program.Main、ConfigRepository.Load、SftpCredentialProvider.Resolve 下中斷點，F5。
   此模式會讀 APSTR 與檢查設定／Credential，但不連 SFTP、不下載、不 INSERT；
   不代表已驗證目標資料表結構、SFTP 權限或 DB 寫入權限。
9. 移除 --validate，放置已完成且超過 60 秒的測試檔，再 F5；
   在 FileService.Download 與 TransferRepository.InsertIfMissing 檢查內容。
   這次會真正下載及寫入 TEST DB。CSV/TXT/ZIP 都只讀成 byte[]。
10. 驗證 DX3 檔案內容、DB DATALENGTH(FileData)、CorpNo、FileName 和指定的 FileState。
    重跑相同檔名應 SKIP，不多寫一筆。

## 資料表寫入與 TODO

目前依前一段對話欄位設計：
CorpNo nchar(10)、FileName nvarchar(120)、FileData image、FileState char(1)、
AddressIp char(20)、NowMonth char(10)、Bid_Date datetime、Bid_Man nvarchar(50)。

FileData 使用 SqlDbType.Image；Bid_Date 使用 SQL Server GETDATE()。
BidMan 可設定，預設 SftpDx3Receiver。AddressIp / NowMonth 不自行推算。
iNo、Upd_date、Upd_man 由 DB 的 identity/default/nullable 處理，須驗證既有 DDL。
若既有 DDL 不同，修正 TransferRepository 再開啟 SchemaReviewed。

**TODO：FileState 的 R/Z 意義與狀態轉換尚未確認。**
沒有預設狀態，空值會停止執行。初版只寫明確設定值，不實作後續狀態轉換。
**TODO：SftpCredentialProvider.Resolve 實作 sftpAppCode/sftpResCode=FTP_0002
對應的企業資源服務、解密或祕密管理流程。**
初版沒有正式密碼，不推測 FTP_0002 是帳號或密碼。
**TODO：AddressIp、NowMonth、建立／更新欄位的業務語意與時區。**

## 檔案、失敗與防重行為

- 只掃指定目錄第一層一般檔案，略過目錄、symbolic link、.part 檔，
  以及未達 MinimumFileAgeSeconds 的檔案；不遞迴、不解壓、不解析內容。
- 暫緩檔案列入 deferred，沒有失敗時退出碼仍為 0，需由後續排程再收。
- 輸出位置：
  sftpLocalPathXX / CorpNo / UTC日期yyyyMMdd / 每次下載GUID / 原始檔名。
  原始檔名不變。每次下載獨立目錄，避免同名覆寫或多程序 .part 衝突。
- DX3 本機磁碟路徑只有在 DX3 執行才代表 DX3；
  從開發機寫到 DX3 須使用可存取的 UNC share，並確認執行帳號權限。
- .part 下載完後 Flush、比較下載前後 remote size / last-write time、
  本機 size，再同目錄改名。失敗嘗試清理自己的 .part；硬中止可能留孤兒檔。
- 大小／時間一致不是內容 hash 或「上游已完成」的絕對保證；
  上游應先寫暫存檔，再以原子 rename 發布完成檔。
- MaxFileBytes 預設 100 MiB；完整 ReadAllBytes 需要記憶體，設定時保留餘裕。
- 初步以 CorpNo+FileName 防重，依 SQL Server collation 比對。
  同公司同名但不同內容仍 SKIP；不以日期、hash 或 FileState 判斷。
- INSERT 在 Serializable transaction + UPDLOCK/HOLDLOCK 下再次查重；
  並行可能發生 deadlock，此時回報失敗，交由 Control-M 重跑。
  DBA 可評估索引以改善鎖定與查詢；唯一索引需先處理既有重複與其他寫入者。
- DB 失敗保留已完成本機檔。重跑從 SFTP 重新下載到另一個目錄後再 INSERT，
  不把孤兒檔直接當作已成功；DB 與 filesystem 並非分散式原子交易。
  確認成功後的重跑會略過，未自動清理失敗目錄或多程序競爭產生的額外檔。
- SFTP 原檔一律保留，不做 DELETE/MOVE；後續歸檔／清除規則待確認。
- 逐檔錯誤繼續下一檔，逐公司錯誤繼續下一公司；任一失敗整批非零。
  Console 僅記錄例外型別以免洩漏連線／認證資訊；TEST F5 可查看完整例外。

## Control-M 部署

1. 在 VS2022 Build Release。
2. 將 bin/Release 全部輸出部署到 DX3：exe、exe.config、所有相依 DLL。
3. DX3 安裝 .NET Framework 4.8 Runtime；執行帳號須有 DB、SFTP、DX3 目錄權限。
4. 完成正式 Credential TODO、確認 FileState、更新部署的 exe.config 及 APSTR。
5. Control-M Command 直接指定，例如：
   `D:\Batch\SftpDx3Receiver\SftpDx3Receiver.exe`
   工作目錄可指定該部署目錄；不要使用 dotnet xxx.dll。
6. 收集 stdout / stderr。程式不 ReadKey、不跳互動視窗；
   Control-M 排程應避免同批次重疊，失敗可重跑。

| Exit code | 意義 |
|---|---|
| 0 | 執行完成（可為空目錄、全數重複、暫緩檔案），或 --validate 通過 |
| 1 | 連線、參數資料、收檔、IO、DB 或其他執行失敗，含部分失敗 |
| 2 | App.config 未完成、參數用法錯誤或正式 Credential 尚未實作 |

## TEST 驗收清單

- 05/22 各一個小檔成功；FileData 與原檔位元組一致。
- 重跑同一批：筆數不增加；相同檔名跨不同公司可分別入庫。
- 錯誤 host fingerprint：拒絕連線；錯誤 Credential：失敗非零。
- 大檔超限、下載中 remote 改變、DX3 無寫入權限：不 INSERT。
- DB INSERT 失敗後重跑：保留原本下載檔並可重新收檔。
- 不合法／過長 Windows 檔名回報失敗，.part 與過新檔列 deferred。
- FileState 空白與 Resource 未實作：明確停止。
- 在 TEST 做並行防重、DB constraints / trigger、排程帳號權限整合驗證。

實際驗證紀錄見 VALIDATION.md。


