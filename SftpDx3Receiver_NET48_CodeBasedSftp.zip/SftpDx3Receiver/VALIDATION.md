# CodeBasedSftp 版本驗證紀錄

驗證日期：2026-09-15。

- 使用使用者提供的 CodeBasedSftp.cs，保留 namespace 與既有公開方法，補上收檔方法。
- 全部 C# 原始碼搭配本機既有 SSH.NET 2026.0.0 的 net462 DLL 直接編譯成功。
- 此 DLL 僅用於本機相容性檢查，未加入交付 ZIP；專案不固定此版本、不使用 NuGet。
- 專案 XML 與所有 Compile 檔案檢查通過。
- 預設 App.config 啟動回傳 2，明確要求 SchemaReviewed，未存取 DB/SFTP。

## 尚未驗證

尚未取得編譯機共用 DLL 的路徑與版本；需以公司的實際 ref 目錄 Build，
確認 CodeBasedSftp 的 API 及全部相依組件相容 .NET Framework 4.8。
本機無 VS2022 / .NET SDK，未完成完整 MSBuild 參照解析、binding redirects 與輸出 DLL 驗證。
未連線 TEST SQL Server / SFTP，未執行下載或 INSERT 整合測試。
FileState 與 FTP_0002 解析仍保持原 TODO，不推測正式規則。
