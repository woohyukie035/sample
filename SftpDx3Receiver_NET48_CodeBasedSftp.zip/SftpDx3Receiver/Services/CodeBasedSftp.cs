using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace RealTimeNoticeLibrary
{
    /// <summary>
    /// 通用 SFTP 類別：可連線、切換遠端路徑、上傳檔案
    /// </summary>
    public class CodeBasedSftp : IDisposable
    {
        private readonly string _host;
        private readonly int _port;
        private readonly string _userName;
        private readonly string _password;
        private readonly string _privateKeyPath;
        private readonly string _privateKeyPassPhrase;
        private SftpClient _client;
        private PrivateKeyFile _privateKeyFile;
        public int TimeoutSeconds { get; set; }
        public string HostKeySha256 { get; set; }

        // Added for receiver: preserve the existing public methods.
        public Renci.SshNet.Sftp.SftpFileAttributes GetAttributes(string remoteFilePath)
        {
            EnsureConnected();
            return _client.GetAttributes(remoteFilePath);
        }

        public void DownloadFile(string remoteFilePath, Stream destination, Action<ulong> progress = null)
        {
            EnsureConnected();
            if (string.IsNullOrWhiteSpace(remoteFilePath))
                throw new ArgumentException("remoteFilePath is required.");
            if (destination == null || !destination.CanWrite)
                throw new ArgumentException("Writable destination is required.");
            _client.DownloadFile(remoteFilePath, destination, progress);
        }

        /// <summary>
        /// 初始化 SFTP連線所需的主機、帳號密碼與私鑰設定。
        /// </summary>
        /// <param name="host">主機位址</param>
        /// <param name="port">連接埠</param>
        /// <param name="userName">使用者名稱</param>
        /// <param name="password">密碼</param>
        /// <param name="privateKeyPath">私鑰檔案路徑</param>
        /// <param name="privateKeyPassPhrase">私鑰密碼</param>
        public CodeBasedSftp(
            string host,
            int port,
            string userName,
            string password,
            string privateKeyPath = "",
            string privateKeyPassPhrase = "")
        {
            _host = host;
            TimeoutSeconds = 60;
            _port = port;
            _userName = userName;
            _password = password;
            _privateKeyPath = privateKeyPath ?? "";
            _privateKeyPassPhrase = privateKeyPassPhrase ?? "";
        }

        /// <summary>
        /// 取得目前 SFTP連線是否已成功建立。
        /// </summary>
        public bool IsConnected
        {
            get { return _client != null && _client.IsConnected; }
        }

        /// <summary>
        /// 依帳號密碼或私鑰資訊建立並開啟 SFTP連線。
        /// </summary>
        public void Connect()
        {
            if (this.IsConnected)
            {
                return;
            }

            Disconnect();
            if (string.IsNullOrWhiteSpace(HostKeySha256))
                throw new InvalidOperationException("Trusted HostKeySha256 is required.");
            if (!string.IsNullOrWhiteSpace(_privateKeyPath) && !File.Exists(_privateKeyPath))
                throw new FileNotFoundException("Private key file does not exist.", _privateKeyPath);
            ConnectionInfo connectionInfo;

            if (string.IsNullOrWhiteSpace(_privateKeyPath) == false && File.Exists(_privateKeyPath))
            {
                PrivateKeyFile privateKeyFile = string.IsNullOrWhiteSpace(_privateKeyPassPhrase)
                    ? new PrivateKeyFile(_privateKeyPath)
                    : new PrivateKeyFile(_privateKeyPath, _privateKeyPassPhrase);
                _privateKeyFile = privateKeyFile;

                connectionInfo = new ConnectionInfo(
                    _host,
                    _port,
                    _userName,
                    new AuthenticationMethod[]
                    {
                        new PrivateKeyAuthenticationMethod(_userName, privateKeyFile)
                    });
            }
            else
            {
                connectionInfo = new ConnectionInfo(
                    _host,
                    _port,
                    _userName,
                    new AuthenticationMethod[]
                    {
                        new PasswordAuthenticationMethod(_userName, _password)
                    });
            }

            _client = new SftpClient(connectionInfo);
            _client.ConnectionInfo.Timeout = TimeSpan.FromSeconds(TimeoutSeconds);
            _client.OperationTimeout = TimeSpan.FromSeconds(TimeoutSeconds);
            _client.HostKeyReceived += (sender, args) =>
            {
                using (var sha = System.Security.Cryptography.SHA256.Create())
                    args.CanTrust = ("SHA256:" + Convert.ToBase64String(sha.ComputeHash(args.HostKey)).TrimEnd('='))
                        == HostKeySha256.TrimEnd('=');
            };
            try { _client.Connect(); }
            catch { Disconnect(); throw; }
        }

        /// <summary>
        /// 中斷目前 SFTP連線並釋放相關資源。
        /// </summary>
        public void Disconnect()
        {
            try { if (_client != null) _client.Dispose(); }
            finally
            {
                _client = null;
                if (_privateKeyFile != null) _privateKeyFile.Dispose();
                _privateKeyFile = null;
            }
        }

        /// <summary>
        /// 切換目前 SFTP 工作目錄到指定遠端路徑。
        /// </summary>
        /// <param name="remotePath">遠端路徑</param>
        /// <exception cref="ArgumentException">remotePath 不可為空白</exception>
        public void ChangeDirectory(string remotePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remotePath))
            {
                throw new ArgumentException("remotePath 不可為空白");
            }

            _client.ChangeDirectory(remotePath);
        }

        /// <summary>
        /// 檢查指定遠端路徑是否存在且為資料夾。
        /// </summary>
        /// <param name="remotePath">遠端路徑</param>
        /// <returns>如果資料夾存在，則為 true；否則為 false。</returns>
        public bool DirectoryExists(string remotePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remotePath))
            {
                return false;
            }

            return _client.Exists(remotePath) && _client.GetAttributes(remotePath).IsDirectory;
        }

        /// <summary>
        /// 建立指定遠端資料夾，若上層路徑不存在則一併建立。
        /// </summary>
        /// <param name="remotePath">遠端路徑</param>
        /// <exception cref="ArgumentException">remotePath 不可為空白</exception>
        public void CreateDirectory(string remotePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remotePath))
            {
                throw new ArgumentException("remotePath 不可為空白");
            }

            if (DirectoryExists(remotePath))
            {
                return;
            }

            string normalizedPath = remotePath.Replace("\\", "/");
            string[] pathParts = normalizedPath.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            string currentPath = normalizedPath.StartsWith("/") ? "/" : string.Empty;

            foreach (string pathPart in pathParts)
            {
                currentPath = string.IsNullOrEmpty(currentPath) || currentPath == "/"
                    ? currentPath + pathPart
                    : currentPath + "/" + pathPart;

                if (DirectoryExists(currentPath) == false)
                {
                    _client.CreateDirectory(currentPath);
                }
            }
        }

        /// <summary>
        /// 檢查指定遠端路徑是否存在且為一般檔案。
        /// </summary>
        /// <param name="remoteFilePath">遠端檔案路徑</param>
        /// <returns>如果檔案存在，則為 true；否則為 false。</returns>
        public bool FileExists(string remoteFilePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remoteFilePath))
            {
                return false;
            }

            return _client.Exists(remoteFilePath) && _client.GetAttributes(remoteFilePath).IsRegularFile;
        }

        /// <summary>
        /// 取得指定遠端資料夾下的所有一般檔案名稱。
        /// </summary>
        /// <param name="remotePath">遠端資料夾路徑</param>
        /// <returns>檔案名稱列表</returns>
        /// <exception cref="ArgumentException">remotePath 不可為空白</exception>
        /// <exception cref="DirectoryNotFoundException">遠端路徑不存在</exception>
        public List<string> GetFiles(string remotePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remotePath))
            {
                throw new ArgumentException("remotePath 不可為空白");
            }

            if (DirectoryExists(remotePath) == false)
            {
                throw new DirectoryNotFoundException("遠端路徑不存在: " + remotePath);
            }

            return _client.ListDirectory(remotePath)
                .Where(x => x.Name != "." && x.Name != ".." && x.IsRegularFile && !x.IsSymbolicLink)
                .Select(x => x.Name)
                .ToList();
        }

        /// <summary>
        /// 將遠端檔案搬移或重新命名到指定的新路徑。
        /// </summary>
        /// <param name="sourceRemoteFilePath">來源遠端檔案路徑</param>
        /// <param name="destinationRemoteFilePath">目的地遠端檔案路徑</param>
        /// <exception cref="ArgumentException">來源或目的地檔案路徑不可為空白</exception>
        public void MoveFile(string sourceRemoteFilePath, string destinationRemoteFilePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(sourceRemoteFilePath))
            {
                throw new ArgumentException("sourceRemoteFilePath 不可為空白");
            }

            if (string.IsNullOrWhiteSpace(destinationRemoteFilePath))
            {
                throw new ArgumentException("destinationRemoteFilePath 不可為空白");
            }

            string destinationDirectory = GetDirectoryName(destinationRemoteFilePath);
            if (string.IsNullOrWhiteSpace(destinationDirectory) == false && DirectoryExists(destinationDirectory) == false)
            {
                CreateDirectory(destinationDirectory);
            }

            _client.RenameFile(sourceRemoteFilePath, destinationRemoteFilePath);
        }

        /// <summary>
        /// 刪除指定的遠端檔案。
        /// </summary>
        /// <param name="remoteFilePath">遠端檔案路徑</param>
        /// <exception cref="ArgumentException">remoteFilePath 不可為空白</exception>
        /// <exception cref="FileNotFoundException">遠端檔案不存在</exception>
        public void DeleteFile(string remoteFilePath)
        {
            EnsureConnected();

            if (string.IsNullOrWhiteSpace(remoteFilePath))
            {
                throw new ArgumentException("remoteFilePath 不可為空白");
            }

            if (FileExists(remoteFilePath) == false)
            {
                throw new FileNotFoundException("遠端檔案不存在", remoteFilePath);
            }

            _client.DeleteFile(remoteFilePath);
        }

        /// <summary>
        /// 組合遠端資料夾路徑與檔名或子資料夾名稱。
        /// </summary>
        /// <param name="remotePath">遠端資料夾路徑</param>
        /// <param name="fileOrFolderName">檔名或子資料夾名稱</param>
        /// <returns>組合後的遠端完整路徑</returns>
        /// <exception cref="ArgumentException">remotePath 或 fileOrFolderName 不可為空白</exception>
        public string CombineRemotePath(string remotePath, string fileOrFolderName)
        {
            if (string.IsNullOrWhiteSpace(remotePath))
            {
                throw new ArgumentException("remotePath 不可為空白");
            }

            if (string.IsNullOrWhiteSpace(fileOrFolderName))
            {
                throw new ArgumentException("fileOrFolderName 不可為空白");
            }

            string normalizedRemotePath = remotePath.Replace("\\", "/").TrimEnd('/');
            string normalizedFileOrFolderName = fileOrFolderName.Replace("\\", "/").TrimStart('/');
            return normalizedRemotePath + "/" + normalizedFileOrFolderName;
        }

        /// <summary>
        /// 將本機檔案上傳到指定遠端資料夾，可自訂上傳後檔名。
        /// </summary>
        /// <param name="localFilePath">本機檔案路徑</param>
        /// <param name="remotePath">遠端資料夾路徑</param>
        /// <param name="remoteFileName">遠端檔案名稱</param>
        /// <exception cref="FileNotFoundException">找不到要上傳的檔案</exception>
        /// <exception cref="ArgumentException">remotePath 不可為空白</exception>
        /// <exception cref="DirectoryNotFoundException">遠端路徑不存在</exception>
        public void UploadFile(string localFilePath, string remotePath, string remoteFileName = "")
        {
            EnsureConnected();

            if (File.Exists(localFilePath) == false)
            {
                throw new FileNotFoundException("找不到要上傳的檔案", localFilePath);
            }

            if (string.IsNullOrWhiteSpace(remotePath))
            {
                throw new ArgumentException("remotePath 不可為空白");
            }

            if (_client.Exists(remotePath) == false)
            {
                throw new DirectoryNotFoundException("遠端路徑不存在: " + remotePath);
            }

            _client.ChangeDirectory(remotePath);

            string uploadFileName = string.IsNullOrWhiteSpace(remoteFileName)
                ? Path.GetFileName(localFilePath)
                : remoteFileName;

            using (FileStream fs = new FileStream(localFilePath, FileMode.Open, FileAccess.Read))
            {
                _client.BufferSize = 1024;
                _client.UploadFile(fs, uploadFileName);
            }
        }

        /// <summary>
        /// 取得遠端完整檔案路徑所屬的資料夾路徑。
        /// </summary>
        /// <param name="remoteFilePath">遠端檔案路徑</param>
        /// <returns>資料夾路徑</returns>
        private string GetDirectoryName(string remoteFilePath)
        {
            string normalizedPath = remoteFilePath.Replace("\\", "/");
            int lastSlashIndex = normalizedPath.LastIndexOf('/');
            if (lastSlashIndex <= 0)
            {
                return lastSlashIndex == 0 ? "/" : string.Empty;
            }

            return normalizedPath.Substring(0, lastSlashIndex);
        }

        /// <summary>
        /// 確認目前 SFTP連線已建立，否則拋出例外。
        /// </summary>
        private void EnsureConnected()
        {
            if (this.IsConnected == false)
            {
                throw new InvalidOperationException("SFTP 尚未連線");
            }
        }

        /// <summary>
        /// 釋放物件時自動中斷 SFTP連線並清理資源。
        /// </summary>
        public void Dispose()
        {
            Disconnect();
        }

    }
}
