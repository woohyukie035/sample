using System;
using System.IO;
using RealTimeNoticeLibrary;
using SftpDx3Receiver.Models;
using SftpDx3Receiver.Repositories;
namespace SftpDx3Receiver.Services
{
    public sealed class SftpReceiveService
    {
        private readonly BatchSettings settings;
        public SftpReceiveService(BatchSettings value) { settings = value; }
        public int Run(ReceiveConfig config, SftpCredential credential)
        {
            int failures = 0, inserted = 0, skipped = 0, deferred = 0;
            var repository = new TransferRepository(settings);
            var files = new FileService();
            using (var client = new CodeBasedSftp(config.Host, config.Port, credential.UserName, credential.Password))
            {
                client.TimeoutSeconds = settings.Timeout;
                client.HostKeySha256 = settings.Fingerprint;
                client.Connect();
                foreach (var company in config.Companies)
                {
                    try
                    {
                        foreach (var fileName in client.GetFiles(company.RemotePath))
                        {
                            try
                            {
                                FileService.ValidateName(fileName);
                                string remote = client.CombineRemotePath(company.RemotePath, fileName);
                                var attributes = client.GetAttributes(remote);
                                if (fileName.EndsWith(".part", StringComparison.OrdinalIgnoreCase) ||
                                    (DateTime.UtcNow - attributes.LastWriteTimeUtc).TotalSeconds < settings.MinimumAge)
                                { deferred++; continue; }
                                if (repository.Exists(company.CorpNo, fileName))
                                { skipped++; LogService.Info("SKIP " + company.CorpNo + "/" + fileName); continue; }
                                string directory = Path.Combine(company.LocalPath, company.CorpNo,
                                    DateTime.UtcNow.ToString("yyyyMMdd"), Guid.NewGuid().ToString("N"));
                                string local = files.Download(client, remote,
                                    directory, fileName, settings.MaxFileBytes);
                                // Preserve downloaded file if DB fails. Retry downloads to a new attempt directory.
                                bool added = repository.InsertIfMissing(new TransferRecord {
                                    CorpNo = company.CorpNo, FileName = fileName, FileData = files.ReadBinary(local)
                                });
                                if (added) inserted++; else skipped++;
                                LogService.Info((added ? "INSERT " : "SKIP race ") + company.CorpNo + "/" + fileName + " local=" + local);
                            }
                            catch (Exception ex)
                            {
                                failures++;
                                LogService.Error(company.CorpNo + "/" + fileName + " failed: " + ex.GetType().Name);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        failures++; LogService.Error("Company " + company.CorpNo + " failed: " + ex.GetType().Name);
                    }
                }
                client.Disconnect();
            }
            LogService.Info("Summary inserted=" + inserted + " skipped=" + skipped + " deferred=" + deferred + " failed=" + failures);
            return failures == 0 ? 0 : 1;
        }
    }
}
